# Tones
!NOTICE! This repository is demonstration.

## Features
- Based on music theory.
- Treat music note as The following classes, Tonality,Time, and Note.
- You handle the relationship of Note,Tonality and Time easily.

## Usage
Set data to read for example.

```python
import Tones as t

tonality = t.Tonality('C','Major')
time = t.Time('4','4')
note = t.Note('C',1,'4',tonality,time)

print(note.display())
tonality.transpose(0.5)
print(note.display())
``` 

### Tonality
At first, You set 'tonal' value by selecting 'Major' or 'minor'.

Second, You set 'key' value by selecting below.
If the 'tonal' value you selected is 'Major',Select in 'Major key list',
Or 'minor',select in 'minor key list'.
(+ means sharp,- means flat)
- Major list : C,D-,D,E-,E,F,G-,G,A-,A,B-,B,C+,F+,C-
- minor list : C,C+,D,D+,E,F,F+,G,G+,A,A+,B,E-,A-,B-

### Time
Third, 'beats' value is allowed to set by the following rules.

- write numerator and denominator in 2,4,8. ...e.g. '4/4','3/4','6/8'

### Note
Next, You set 'notes' arrays by following rules.

- One list block means division,Amount of 'notes.length' in that is following beat you set.
- One dict in list block means note,Consist of 'height','octave' and 'length'.
- 'height' value is allowed to set Ionian Notes adding to '+' or '-' ...e.g. 'C','D-','A+'.
  And plus one element that signed to 'R'(mean rest).
- 'octave' value is allowed to set 1,2,3,4,5
- 'length' value is allowed to set 2,4,8,16,32


